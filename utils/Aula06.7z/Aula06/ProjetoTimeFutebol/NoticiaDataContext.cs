﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoTimeFutebol
{
    class NoticiaDataContext : DataContext
    {
        public Table<Noticia> news;
        //conexao
        static string CONNECT = "isostore:/futebol_news.sdf";

        public NoticiaDataContext()
            : base(CONNECT)
        {

        }
    }
}
