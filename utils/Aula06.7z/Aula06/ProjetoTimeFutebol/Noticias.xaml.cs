﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using System.Xml.Linq;
using Microsoft.Phone.Tasks;
using System.IO.IsolatedStorage;

namespace ProjetoTimeFutebol
{
    public partial class Noticias : PhoneApplicationPage
    {
        private IList<Noticia> lista;

        public Noticias()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            if (this.NavigationContext.QueryString.ContainsKey(MainPage.KEY_TIME))
            {
                string time = this.NavigationContext.QueryString[MainPage.KEY_TIME];
                carregarNoticias(time);

            }

            NavigationService.RemoveBackEntry();

        }


        private void carregarNoticias(string time)
        {
            lblTitulo.Text = time;

            ProgressIndicator p = new ProgressIndicator();
            p.IsVisible = true;
            p.IsIndeterminate = true;
            p.Text = "Carregando...";

            SystemTray.SetProgressIndicator(this, p);

            Uri uri = new Uri("http://esporte.uol.com.br/futebol/clubes/" + time + ".xml");
            WebClient client = new WebClient();
            client.OpenReadCompleted += client_OpenReadCompleted;
            client.OpenReadAsync(uri);
        }

        private void client_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            XDocument doc = XDocument.Load(e.Result);
            lista = new List<Noticia>();

            foreach (var item in doc.Descendants("item"))
            {
                Noticia noticia = new Noticia();
                noticia.Title = string.Format("{0}", (string)item.Element("title"));
                noticia.Link = string.Format("{0}", (string)item.Element("link"));

                lista.Add(noticia);

            }

            lstNoticias.ItemsSource = lista;
            SystemTray.ProgressIndicator.IsVisible = false;
        }

        private void lstNoticias_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(lstNoticias.SelectedIndex >= 0)
            {
                Noticia noticia = lista.ElementAt(lstNoticias.SelectedIndex);

                WebBrowserTask webBrowserTask = new WebBrowserTask();

                webBrowserTask.Uri = new Uri(noticia.Link, UriKind.Absolute);

                webBrowserTask.Show();
            }
            
        }

        private void MudarTime_Click(object sender, EventArgs e)
        {
            var settings = IsolatedStorageSettings.ApplicationSettings;
            settings[MainPage.KEY_TIME] = "";

            /*if(NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }else
            {
                NavigationService.Navigate(new Uri("/MainPage.xaml?back=true", UriKind.Relative));
            }*/

            NavigationService.Navigate(new Uri("/MainPage.xaml?back=true", UriKind.Relative));
        }

        private void CriarTile_Click(object sender, EventArgs e)
        {
            

            

            string time = this.NavigationContext.QueryString[MainPage.KEY_TIME];
            StandardTileData data = new StandardTileData();
            data.Title = time;

            string url = "/Noticias.xaml?" + MainPage.KEY_TIME + "=" + time;

            ShellTile shellTile = ShellTile.ActiveTiles.FirstOrDefault(
            tile => tile.NavigationUri.ToString().Contains(url));


            if(shellTile != null)
            {
                MessageBox.Show("Tile ja criado anteriormente!");
            }else
            {
                Uri uri = new Uri(url, UriKind.Relative);

                ShellTile.Create(uri, data);
            }
            
        }

        private void AbrirFavoritos_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/Favoritos.xaml", UriKind.Relative));
        }



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            Noticia noticia = (Noticia)btn.DataContext;

            Persistencia p = new Persistencia();

            p.Insert(noticia);

            MessageBox.Show("Noticia salva!");
        }
    }
}