﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using ProjetoTimeFutebol.Resources;
using System.IO.IsolatedStorage;

namespace ProjetoTimeFutebol
{
    public partial class MainPage : PhoneApplicationPage
    {
        public static string KEY_TIME = "time";

        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            var settings = IsolatedStorageSettings.ApplicationSettings;

            if (!settings.Contains("back"))
            {
                if (settings.Contains(KEY_TIME))
                {
                    if (settings[KEY_TIME].ToString().Length > 0)
                        gotoNoticias(settings[KEY_TIME].ToString());
                }
            }

            NavigationService.RemoveBackEntry();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            string tag = btn.Tag.ToString();

            var settings = IsolatedStorageSettings.ApplicationSettings;

            settings[KEY_TIME] = tag;
            settings.Save();

            gotoNoticias(tag);
        }

        private void gotoNoticias(string time)
        {
            NavigationService.Navigate(new Uri("/Noticias.xaml?" + KEY_TIME + "=" + time, UriKind.Relative));
        }
    }
}