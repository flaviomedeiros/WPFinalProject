﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoTimeFutebol
{
    public class Persistencia
    {
        public void Insert(Noticia noticia)
        {
            using (NoticiaDataContext db = new NoticiaDataContext())
            {
                db.news.InsertOnSubmit(noticia);
                db.SubmitChanges();
            }

        }

        public IList<Noticia> GetNews()
        {
            using (NoticiaDataContext db = new NoticiaDataContext())
            {
                IList<Noticia> lista = (from al in db.news
                                        select al).ToList();

                return lista;
            }

        }
    }
}
