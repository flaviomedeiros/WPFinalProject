﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.Phone.Tasks;

namespace ProjetoTimeFutebol
{
    public partial class Favoritos : PhoneApplicationPage
    {
        private IList<Noticia> lista;

        public Favoritos()
        {
            InitializeComponent();

            Persistencia p = new Persistencia();

            lista = p.GetNews();

            lstNoticias.ItemsSource = lista;
        }

        private void lstNoticias_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstNoticias.SelectedIndex >= 0)
            {
                Noticia noticia = lista.ElementAt(lstNoticias.SelectedIndex);

                WebBrowserTask webBrowserTask = new WebBrowserTask();

                webBrowserTask.Uri = new Uri(noticia.Link, UriKind.Absolute);

                webBrowserTask.Show();
            }
        }
    }
}