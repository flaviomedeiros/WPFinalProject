﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using ExemploFiker.Resources;
using System.Runtime.Serialization.Json;

namespace ExemploFiker
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            Uri url = new Uri("https://api.flickr.com/services/rest/?method=flickr.interestingness.getList&api_key=0824635474307ddd7227504a282336db&format=json&nojsoncallback=1&api_sig=7f813fd8a3937e30aa8396bd98b2b440");
            WebClient c = new WebClient();

            c.OpenReadCompleted += c_OpenReadCompleted;

            c.OpenReadAsync(url);

            ProgressIndicator p = new ProgressIndicator();
            p.IsVisible = true;
            p.IsIndeterminate = true;
            p.Text = "Carregando...";

            SystemTray.SetProgressIndicator(this, p);
        }

        void c_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            DataContractJsonSerializer serial = new DataContractJsonSerializer(typeof(FlickrResult));
            FlickrResult result = (FlickrResult)serial.ReadObject(e.Result);

            lstImagens.ItemsSource = result.Photos.Photo;

            SystemTray.ProgressIndicator.IsVisible = false;
        }

        
    }
}