﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using BDEscola.Resources;

namespace BDEscola
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
            carregarAlunos();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Aluno novoAluno = new Aluno();

            novoAluno.Nome = txtNome.Text;
            novoAluno.Matricula = Convert.ToInt32(txtMatricula.Text);

            using (var db = new EscolaDataContext(EscolaDataContext.CN))
            {
                db.Alunos.InsertOnSubmit(novoAluno);
                db.SubmitChanges();

                txtNome.Text = "";
                txtMatricula.Text = String.Empty;

                MessageBox.Show("Adicionado!");

                carregarAlunos();
            }
        }

        void carregarAlunos()
        {
            using (var db = new EscolaDataContext(EscolaDataContext.CN))
            {
                List<Aluno> lista = (from al in db.Alunos
                                     select al).ToList();

                lstAlunos.ItemsSource = lista;
            }

        }

        private void btnApagar_Click(object sender, RoutedEventArgs e)
        {
            if(MessageBox.Show("Tem certeza?","Remover", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                Button btn = (Button)sender;
                Aluno aluno = (Aluno)btn.DataContext;
                //int id = Convert.ToInt32(btn.Tag.ToString());

                using (var db = new EscolaDataContext(EscolaDataContext.CN))
                {
                    db.Alunos.Attach(aluno); //dizer que esse aluno esta no banco
                    db.Alunos.DeleteOnSubmit(aluno);
                    db.SubmitChanges();
                    carregarAlunos();

                    /*List<Aluno> lista = (from al in db.Alunos
                                         where al.Id == id
                                         select al).ToList();

                    if(lista.Count  > 0)
                    {
                        db.Alunos.DeleteOnSubmit(lista.ElementAt(0));
                        db.SubmitChanges();
                        carregarAlunos();
                    }*/


                }
            }

            
        }
    }
}