﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDEscola
{
    public class EscolaDataContext: DataContext
    {
        public static string CN = "isostore:/escola.sdf";

        public Table<Aluno> Alunos;

        public EscolaDataContext(string cn):base(cn)
        {

        }
        
    }
}
