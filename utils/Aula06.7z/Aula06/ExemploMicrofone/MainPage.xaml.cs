﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using ExemploMicrofone.Resources;
using Microsoft.Xna.Framework.Audio;
using System.IO;
using System.Windows.Threading;
using Microsoft.Xna.Framework;

namespace ExemploMicrofone
{
    public partial class MainPage : PhoneApplicationPage
    {
        Microphone mic = Microphone.Default;
        byte[] buffer;
        MemoryStream stream;
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(50);
            timer.Tick += delegate { FrameworkDispatcher.Update(); };
            timer.Start();

            mic.BufferDuration = TimeSpan.FromSeconds(1);

            mic.BufferReady += mic_BufferReady;
        }

        void mic_BufferReady(object sender, EventArgs e)
        {
            mic.GetData(buffer);
            stream.Write(buffer, 0, buffer.Length);
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            stream = new MemoryStream();
            buffer = new byte[mic.GetSampleSizeInBytes(mic.BufferDuration)];

            mic.Start();
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            mic.Stop();
        }

        private void btnPlay_Click(object sender, RoutedEventArgs e)
        {
            var som = new SoundEffect(stream.ToArray(), mic.SampleRate, AudioChannels.Mono);
            SoundEffect.MasterVolume = 0.7f;

            som.Play();
        }

        // Sample code for building a localized ApplicationBar
        //private void BuildLocalizedApplicationBar()
        //{
        //    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        //    ApplicationBar = new ApplicationBar();

        //    // Create a new button and set the text value to the localized string from AppResources.
        //    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        //    appBarButton.Text = AppResources.AppBarButtonText;
        //    ApplicationBar.Buttons.Add(appBarButton);

        //    // Create a new menu item with the localized string from AppResources.
        //    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        //    ApplicationBar.MenuItems.Add(appBarMenuItem);
        //}
    }
}