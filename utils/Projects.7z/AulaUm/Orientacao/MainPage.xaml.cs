﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Orientacao.Resources;
using System.Windows.Media;


namespace Orientacao
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        protected override void OnOrientationChanged(OrientationChangedEventArgs e)
        {
            base.OnOrientationChanged(e);

            if (e.Orientation == PageOrientation.LandscapeRight || e.Orientation == PageOrientation.LandscapeLeft)
            {
                btnUm.VerticalAlignment = VerticalAlignment.Top;
                btnDois.VerticalAlignment = VerticalAlignment.Top;
                btnUm.Background = new SolidColorBrush(Colors.Yellow);
                btnDois.Background = new SolidColorBrush(Colors.Yellow);
            }else
            {
                btnUm.VerticalAlignment = VerticalAlignment.Bottom;
                btnDois.VerticalAlignment = VerticalAlignment.Bottom;
                btnUm.Background = new SolidColorBrush(Colors.Black);
                btnDois.Background = new SolidColorBrush(Colors.Black);
            }
        }
    }
}