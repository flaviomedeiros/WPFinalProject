﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using LockScreen.Resources;
using Windows.Phone.System.UserProfile;

namespace LockScreen
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            bool isOK = LockScreenManager.IsProvidedByCurrentApplication;

            if(!isOK)
            {
                var op = await LockScreenManager.RequestAccessAsync();

                isOK = op == LockScreenRequestResult.Granted;
            }

            if(isOK)
            {
                MessageBox.Show("Tudo ok! =D");

                //Windows.Phone.System.UserProfile.LockScreen.SetImageUri( new Uri("ms-appx:///Assets/img/jpg", UriKind.Absolute));

            }else
            {
                MessageBox.Show("Afff...");
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ShellTile tile = ShellTile.ActiveTiles.First();

            FlipTileData data = new FlipTileData();
            //data.WideBackContent = "Boa noite";
            data.Count = 20;

            tile.Update(data);
        }

        // Sample code for building a localized ApplicationBar
        //private void BuildLocalizedApplicationBar()
        //{
        //    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        //    ApplicationBar = new ApplicationBar();

        //    // Create a new button and set the text value to the localized string from AppResources.
        //    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        //    appBarButton.Text = AppResources.AppBarButtonText;
        //    ApplicationBar.Buttons.Add(appBarButton);

        //    // Create a new menu item with the localized string from AppResources.
        //    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        //    ApplicationBar.MenuItems.Add(appBarMenuItem);
        //}
    }
}