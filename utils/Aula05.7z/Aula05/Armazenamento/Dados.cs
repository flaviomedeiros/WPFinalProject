﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Armazenamento
{
    public class Dados
    {
        public string nome { get; set; }
    }
}
