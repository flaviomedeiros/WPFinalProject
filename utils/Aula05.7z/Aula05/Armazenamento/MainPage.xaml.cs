﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Armazenamento.Resources;
using System.IO.IsolatedStorage;
using System.Xml.Serialization;
using System.IO;

namespace Armazenamento
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Dados d = new Dados();
            d.nome = "Elano";

           using(var store = IsolatedStorageFile.GetUserStoreForApplication())
            using(var stream = new IsolatedStorageFileStream("dados.txt",
                                                               System.IO.FileMode.Create, System.IO.FileAccess.Write, store))
            {
                XmlSerializer serial = new XmlSerializer(typeof(Dados));

                serial.Serialize(stream, d);

                MessageBox.Show("Foi!");
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            using (var store = IsolatedStorageFile.GetUserStoreForApplication())
            using (var stream = new IsolatedStorageFileStream("dados.txt",
                                                               System.IO.FileMode.Open, store))
            using(var sr = new StreamReader(stream))
            {
                //XmlSerializer serial = new XmlSerializer(typeof(Dados));

              

                MessageBox.Show(sr.ReadToEnd());
            }
        }

        private void btnEscrever_Click(object sender, RoutedEventArgs e)
        {
            using (var store = IsolatedStorageFile.GetUserStoreForApplication())
            using (var stream = new IsolatedStorageFileStream("dados.txt",
                                                               System.IO.FileMode.Create, store))
            using (var sw = new StreamWriter(stream))
            {
                //XmlSerializer serial = new XmlSerializer(typeof(Dados));
                sw.Write("Elano Elano !!");
            }
        }

        private void btnSetting_Click(object sender, RoutedEventArgs e)
        {
            var settings = IsolatedStorageSettings.ApplicationSettings;

            settings["nome"] = "Elano";
            settings.Save();
        }

        private void btnSettingLer_Click(object sender, RoutedEventArgs e)
        {
            var settings = IsolatedStorageSettings.ApplicationSettings;

            if(settings.Contains("nome"))
            {
                MessageBox.Show(settings["nome"].ToString());
            }
        }

        // Sample code for building a localized ApplicationBar
        //private void BuildLocalizedApplicationBar()
        //{
        //    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        //    ApplicationBar = new ApplicationBar();

        //    // Create a new button and set the text value to the localized string from AppResources.
        //    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        //    appBarButton.Text = AppResources.AppBarButtonText;
        //    ApplicationBar.Buttons.Add(appBarButton);

        //    // Create a new menu item with the localized string from AppResources.
        //    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        //    ApplicationBar.MenuItems.Add(appBarMenuItem);
        //}
    }
}